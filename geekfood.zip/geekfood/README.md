# GeekFood 🍔

A full React food website with dark aesthetic. Built with Vite + React Router.

## Pages
- `/` — Home (hero, featured recipes, quote teaser)
- `/recipes` — All recipes with category filter
- `/quote` — Quotes grid (props + map)
- `/about` — About page

## Stack
- React 18 + Vite
- React Router DOM v6
- CSS Modules (component-scoped)
- Google Fonts: Bebas Neue, Outfit, Playfair Display

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
```bash
npm run build
# Push to GitHub → import on vercel.com
```

> For React Router SPA on Vercel, add a `vercel.json`:
```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/" }]
}
```
