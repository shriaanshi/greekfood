const recipes = [
  {
    id: 1,
    title: "Truffle Mushroom Pasta",
    category: "Pasta",
    time: "25 min",
    difficulty: "Easy",
    rating: 4.8,
    emoji: "🍝",
    color: "#1e1408",
    tag: "Featured"
  },
  {
    id: 2,
    title: "Spicy Korean BBQ Tacos",
    category: "Street Food",
    time: "35 min",
    difficulty: "Medium",
    rating: 4.9,
    emoji: "🌮",
    color: "#1a0808",
    tag: "Trending"
  },
  {
    id: 3,
    title: "Miso Glazed Salmon",
    category: "Seafood",
    time: "20 min",
    difficulty: "Easy",
    rating: 4.7,
    emoji: "🐟",
    color: "#081218",
    tag: "Quick"
  },
  {
    id: 4,
    title: "Smash Burger Stack",
    category: "Burgers",
    time: "15 min",
    difficulty: "Easy",
    rating: 5.0,
    emoji: "🍔",
    color: "#0f1208",
    tag: "Popular"
  },
  {
    id: 5,
    title: "Matcha Tiramisu",
    category: "Desserts",
    time: "45 min",
    difficulty: "Hard",
    rating: 4.6,
    emoji: "🍵",
    color: "#081a0e",
    tag: "New"
  },
  {
    id: 6,
    title: "Ramen From Scratch",
    category: "Soups",
    time: "3 hrs",
    difficulty: "Hard",
    rating: 4.9,
    emoji: "🍜",
    color: "#180e08",
    tag: "Chef's Pick"
  }
];

export default recipes;
