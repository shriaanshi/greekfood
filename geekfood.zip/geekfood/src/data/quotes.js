const quotes = [
  { id: 1, quote: "Cooking is like painting or writing a song. Just as there are only so many notes or colors, there are only so many flavors — it's how you combine them that sets you apart.", author: "Wolfgang Puck", role: "Celebrity Chef" },
  { id: 2, quote: "Food is everything we are. It's an extension of nationalist feeling, ethnic feeling, your personal history, your province, your region, your tribe, your grandma.", author: "Anthony Bourdain", role: "Chef & Author" },
  { id: 3, quote: "People who love to eat are always the best people.", author: "Julia Child", role: "Chef & TV Host" },
  { id: 4, quote: "The secret of good cooking is, first, having a love of it. If you're convinced that cooking is drudgery, you're never going to be good at it.", author: "James Beard", role: "Culinary Pioneer" },
  { id: 5, quote: "One cannot think well, love well, sleep well, if one has not dined well.", author: "Virginia Woolf", role: "Author" },
  { id: 6, quote: "There is no sincerer love than the love of food.", author: "George Bernard Shaw", role: "Playwright" },
  { id: 7, quote: "The discovery of a new dish does more for human happiness than the discovery of a new star.", author: "Jean Anthelme Brillat-Savarin", role: "Gastronome" },
  { id: 8, quote: "Food brings people together on many different levels. It's nourishment of the soul and body; it's truly love.", author: "Giada De Laurentiis", role: "Chef & TV Host" },
  { id: 9, quote: "Good food is very often, even most often, simple food.", author: "Anthony Bourdain", role: "Chef & Author" },
  { id: 10, quote: "A recipe has no soul. You, as the cook, must bring soul to the recipe.", author: "Thomas Keller", role: "Chef" },
  { id: 11, quote: "Cooking is one of the strongest ceremonies for life. It is truly love.", author: "Laura Esquivel", role: "Author" },
  { id: 12, quote: "Eating is a necessity but cooking is an art.", author: "Unknown", role: "Food Wisdom" }
];

export default quotes;
