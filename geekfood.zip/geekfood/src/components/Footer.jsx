import React from "react";
import { Link } from "react-router-dom";
import "./Footer.css";

const Footer = () => (
  <footer className="footer">
    <div className="footer-inner">
      <div className="footer-brand">
        <span className="footer-logo">GEEK<em>FOOD</em></span>
        <p>Recipes for curious minds.<br />Eat boldly. Cook fearlessly.</p>
      </div>
      <div className="footer-links">
        <h4>Explore</h4>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/recipes">Recipes</Link></li>
          <li><Link to="/quote">Quotes</Link></li>
          <li><Link to="/about">About</Link></li>
        </ul>
      </div>
      <div className="footer-links">
        <h4>Categories</h4>
        <ul>
          <li><a href="#">Pasta</a></li>
          <li><a href="#">Burgers</a></li>
          <li><a href="#">Desserts</a></li>
          <li><a href="#">Quick Meals</a></li>
        </ul>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} GeekFood. Built with React.</p>
    </div>
  </footer>
);

export default Footer;
