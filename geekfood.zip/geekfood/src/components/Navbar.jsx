import React, { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import "./Navbar.css";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav className={`navbar${scrolled ? " scrolled" : ""}`}>
      <Link to="/" className="nav-logo">
        GEEK<span>FOOD</span>
      </Link>

      <ul className={`nav-links${open ? " open" : ""}`}>
        {[["Home", "/"], ["Recipes", "/recipes"], ["Quotes", "/quote"], ["About", "/about"]].map(([label, path]) => (
          <li key={path}>
            <NavLink to={path} end={path === "/"} className={({ isActive }) => isActive ? "active" : ""} onClick={() => setOpen(false)}>
              {label}
            </NavLink>
          </li>
        ))}
      </ul>

      <div className="nav-right">
        <button className="nav-cta">Subscribe</button>
        <button className="nav-burger" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          <span /><span /><span />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
