import React from "react";
import "./QuoteCard.css";

const QuoteCard = ({ quote, author, role }) => (
  <article className="qcard">
    <span className="qcard-mark" aria-hidden="true">"</span>
    <p className="qcard-text">{quote}</p>
    <div className="qcard-author">
      <div className="qcard-avatar" aria-hidden="true">{author.charAt(0)}</div>
      <div>
        <span className="qcard-name">{author}</span>
        <span className="qcard-role">{role}</span>
      </div>
    </div>
  </article>
);

export default QuoteCard;
