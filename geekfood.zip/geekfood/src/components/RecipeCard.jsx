import React from "react";
import "./RecipeCard.css";

const RecipeCard = ({ title, category, time, difficulty, rating, emoji, color, tag }) => (
  <article className="recipe-card" style={{ "--card-bg": color }}>
    <div className="card-emoji-wrap">
      <span className="card-emoji">{emoji}</span>
    </div>
    <div className="card-body">
      {tag && <span className="card-tag">{tag}</span>}
      <h3 className="card-title">{title}</h3>
      <p className="card-category">{category}</p>
      <div className="card-meta">
        <span>⏱ {time}</span>
        <span className={`card-diff diff-${difficulty.toLowerCase()}`}>{difficulty}</span>
      </div>
      <div className="card-footer">
        <span className="card-rating">★ {rating.toFixed(1)}</span>
        <button className="card-btn">View Recipe →</button>
      </div>
    </div>
  </article>
);

export default RecipeCard;
