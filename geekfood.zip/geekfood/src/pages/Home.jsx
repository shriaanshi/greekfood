import React from "react";
import { Link } from "react-router-dom";
import RecipeCard from "../components/RecipeCard";
import recipes from "../data/recipes";
import "./Home.css";

const Home = () => (
  <main className="home">
    <section className="hero">
      <div className="hero-content">
        <p className="hero-eyebrow">Welcome to GeekFood</p>
        <h1 className="hero-title">
          FOOD FOR<br />
          <span>CURIOUS</span><br />
          MINDS
        </h1>
        <p className="hero-sub">
          Bold recipes. Deep techniques. Fearless flavors.<br />
          For the geek in every kitchen.
        </p>
        <div className="hero-actions">
          <Link to="/recipes" className="btn-primary">Explore Recipes</Link>
          <Link to="/quote" className="btn-ghost">Read Quotes →</Link>
        </div>
        <div className="hero-stats">
          <div className="stat"><strong>200+</strong><span>Recipes</span></div>
          <div className="stat-div" />
          <div className="stat"><strong>50k</strong><span>Readers</span></div>
          <div className="stat-div" />
          <div className="stat"><strong>4.9★</strong><span>Rating</span></div>
        </div>
      </div>
      <div className="hero-visual" aria-hidden="true">
        <div className="hero-ring ring1" />
        <div className="hero-ring ring2" />
        <div className="hero-big-emoji">🍔</div>
      </div>
    </section>

    <section className="section">
      <div className="section-head">
        <span className="section-label">Hand-picked</span>
        <h2>Featured Recipes</h2>
      </div>
      <div className="recipes-grid">
        {recipes.map(r => <RecipeCard key={r.id} {...r} />)}
      </div>
      <div className="section-cta">
        <Link to="/recipes" className="btn-outline">View all recipes →</Link>
      </div>
    </section>

    <section className="marquee-section" aria-hidden="true">
      <div className="marquee-track">
        {["Pasta", "Burgers", "Ramen", "Tacos", "Sushi", "Pizza", "Curry", "BBQ",
          "Pasta", "Burgers", "Ramen", "Tacos", "Sushi", "Pizza", "Curry", "BBQ"].map((t, i) => (
          <span key={i}>{t} <em>•</em> </span>
        ))}
      </div>
    </section>

    <section className="section quote-teaser">
      <div className="qt-inner">
        <div className="qt-quote-mark">"</div>
        <blockquote>People who love to eat are always the best people.</blockquote>
        <cite>— Julia Child</cite>
        <Link to="/quote" className="btn-primary" style={{ marginTop: "2rem", display: "inline-block" }}>
          More Quotes
        </Link>
      </div>
    </section>
  </main>
);

export default Home;
