import React, { useState } from "react";
import RecipeCard from "../components/RecipeCard";
import recipes from "../data/recipes";
import "./Recipes.css";

const categories = ["All", "Pasta", "Street Food", "Seafood", "Burgers", "Desserts", "Soups"];

const Recipes = () => {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? recipes : recipes.filter(r => r.category === active);

  return (
    <main className="recipes-page">
      <div className="rp-header">
        <p className="rp-eyebrow">The Collection</p>
        <h1>All Recipes</h1>
        <p className="rp-sub">Browse our full library of bold, tested, and delicious recipes.</p>
      </div>

      <div className="rp-body">
        <div className="filter-bar">
          {categories.map(c => (
            <button
              key={c}
              className={`filter-pill${active === c ? " active" : ""}`}
              onClick={() => setActive(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <p className="rp-count">{filtered.length} recipe{filtered.length !== 1 ? "s" : ""}</p>

        <div className="recipes-grid2">
          {filtered.map(r => <RecipeCard key={r.id} {...r} />)}
        </div>
      </div>
    </main>
  );
};

export default Recipes;
