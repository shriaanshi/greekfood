import React from "react";
import "./About.css";

const About = () => (
  <main className="about-page">
    <div className="about-header">
      <p className="about-eyebrow">Our Story</p>
      <h1>About GeekFood</h1>
    </div>
    <div className="about-body">
      <div className="about-text">
        <p>
          GeekFood was born from a simple belief: great cooking is part science, part art, and entirely obsession. We're here for the people who read recipes like documentation, who treat their kitchen like a lab, and who never stop tinkering until a dish is perfect.
        </p>
        <p>
          We publish recipes with detailed technique breakdowns, the "why" behind every step, and honest difficulty ratings. No shortcuts, no fluff — just excellent food for curious minds.
        </p>
      </div>
      <div className="about-values">
        {[
          { icon: "🔬", title: "Science-backed", desc: "Every recipe is tested and explained with technique in mind." },
          { icon: "🍴", title: "Bold flavors", desc: "We push beyond the basics. Life is too short for bland." },
          { icon: "📖", title: "Educational", desc: "Learn the fundamentals so you can improvise with confidence." },
        ].map(v => (
          <div key={v.title} className="value-card">
            <span className="value-icon">{v.icon}</span>
            <h3>{v.title}</h3>
            <p>{v.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </main>
);

export default About;
