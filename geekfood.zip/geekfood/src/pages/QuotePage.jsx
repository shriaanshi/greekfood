import React from "react";
import QuoteCard from "../components/QuoteCard";
import quotes from "../data/quotes";
import "./QuotePage.css";

const QuotePage = () => (
  <main className="quote-page">
    <div className="qp-header">
      <p className="qp-eyebrow">Food for Thought</p>
      <h1>Inspiring Quotes</h1>
      <p className="qp-sub">
        Words from the greatest minds in food, cooking, and gastronomy.
      </p>
      <div className="qp-count">{quotes.length} quotes</div>
    </div>

    <div className="qp-body">
      <div className="quotes-grid">
        {quotes.map(q => (
          <QuoteCard key={q.id} quote={q.quote} author={q.author} role={q.role} />
        ))}
      </div>
    </div>
  </main>
);

export default QuotePage;
